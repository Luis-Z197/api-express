import express from "express";
import { read } from "./crud/read.js";
import { create } from "./crud/create.js";
const app = express();
const port = 3000;

app.use(express.json())
app.use(express.static('./public'));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get("/usuarios", async (req, res) => {
  let result = await read();
  res.json(result);
});
app.post("/usuarios",async (req, res, next) => {
  const usuario = req.body
  const result = await create(usuario.username, usuario.email, usuario.password)
  res.json(result)
});


app.listen(port, () => {
  console.log(`Mi app funciona en el puerto ${port}`);
});
