import { connection } from "../coneccion.js";

const db = connection
export async function create(username, email, password) {
    try {
        const [results] = await db.query(
            `INSERT INTO usuarios(username, email, password) VALUES(?,?,?)`,
            [username, email, password]
        )
        return results
    } catch (err) {
        console.log(err);
    }
}